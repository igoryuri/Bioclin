<?php

return [
    'locales' => [
        'en',
        'es',
        'pt-br'
    ]
];
