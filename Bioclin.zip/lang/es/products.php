<?php

return [
    'cod_prod' => 'Código de producto',
    'sku' => 'SKU',
    'peso' => 'Peso',
    'comentarios' => 'Comentarios',
];
