<?php

return [
    'title_linha' => 'Productos de línea',
];
