<?php

return [
    'no_result' => 'No se han encontrado resultados',
    'new_search' => 'Realizar una nueva búsqueda',
    'one_result' => 'resultado encontrado para',
    'multiple_result' => 'resultados encontrados para',
];
