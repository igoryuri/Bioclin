<?php

return [
    'polTrocaDevTitle' => 'Política de cambios y devoluciones',
    'polTrocaDev' => 'Política de cambios y devoluciones',
    'detailPolTrocaDev' => '<p>
Dentro de los 7 (siete) días calendario, los productos defectuosos, daños de envío o errores de envío pueden devolverse y / o intercambiarse contactando a nuestro Servicio al Cliente al +55 31 34395454 o customerservice @ bioclin. .com. Los gastos de envío y devolución correrán a cargo del cliente.
</p>',
];
