<?php

return [
    'cod_prod' => 'Product Code',
    'sku' => 'SKU',
    'peso' => 'Weight',
    'comentarios' => 'Comments',
];
