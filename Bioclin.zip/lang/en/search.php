<?php

return [
    'no_result' => 'no results found',
    'new_search' => 'Perform a new search',
    'one_result' => 'result found for',
    'multiple_result' => 'results found for',
];
