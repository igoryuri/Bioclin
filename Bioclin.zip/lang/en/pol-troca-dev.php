<?php

return [
    'polTrocaDevTitle' => 'Exchange & Returns Policy',
    'polTrocaDev' => 'Exchange & Returns Policy',
    'detailPolTrocaDev' => '<p>
    For exchanges or returns contact us by email customerservice@bioclin.com.br
</p>',
];
