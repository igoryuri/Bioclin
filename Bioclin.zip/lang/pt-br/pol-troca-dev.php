<?php

return [
    'polTrocaDevTitle' => 'Política de Trocas e Devoluções',
    'polTrocaDev' => 'Política de Trocas e Devoluções',
    'detailPolTrocaDev' => '<p>
Em até 7 (sete) dias corridos os produtos com defeitos de fabricação, danificados no transporte, ou com erros de remessa poderão ser devolvidos e/ou trocados, bastando que você entre em contato com nosso SAC pelo telefone 0800 031 5454 ou sac@bioclin.com.br. Os custos decorrentes de frete de envio e retorno serão por conta do cliente.
</p>',
];
