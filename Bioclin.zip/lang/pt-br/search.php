<?php

return [
    'no_result' => 'Nenhum resultado encontrado',
    'new_search' => 'Faça uma nova pesquisa',
    'one_result' => 'resultado encontrado para',
    'multiple_result' => 'resultados encontrados para',
];
