<?php

return [
    'cod_prod' => 'Código do produto',
    'peso' => 'Peso',
    'comentarios' => 'Comentários',
];
