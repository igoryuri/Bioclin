<?php

return [
    'title_linha' => 'Produtos da linha',
];
