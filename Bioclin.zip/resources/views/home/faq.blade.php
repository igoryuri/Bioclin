@extends('templates.layout')
@section('content')
    <div class="w-full max-w-7xl mx-auto gap-2 mb-12 min-h-screen">
        <livewire:f-a-q></livewire:f-a-q>
    </div>
@endsection