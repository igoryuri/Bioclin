@extends('templates.layout')
@section('content')
@endsection