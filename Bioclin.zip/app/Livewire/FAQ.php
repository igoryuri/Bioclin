<?php

namespace App\Livewire;

use Livewire\Component;

class FAQ extends Component
{
    public function render()
    {
        return view('livewire.f-a-q');
    }
}
